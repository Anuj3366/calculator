var a=eval("calculator.ans.value")
function log(a){
    return Math.log(a)
}